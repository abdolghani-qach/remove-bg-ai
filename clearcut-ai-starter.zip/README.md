# ClearCut AI — Background Remover starter

A mobile-friendly Vite app using `@imgly/background-removal` to remove image backgrounds in the browser.

## Current status
- Image upload and validation
- Browser-side background removal
- Transparent PNG preview and download
- Mobile-responsive UI
- **AdBlueMedia Content Locker is intentionally not wired yet.** Do not gate downloads until the completion-verification flow is configured and tested.

## Run locally
```bash
npm install
npm run dev
```

## Deploy to Vercel from a phone
1. Create a new GitHub repository (for example `clearcut-ai`).
2. Upload these project files to the repository, preserving the `src/` folder.
3. In Vercel, choose **Add New → Project**, import the GitHub repository.
4. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`.
5. Deploy. Vercel installs dependencies from `package.json`.

## Important
- The first use downloads the AI model and may be slow on mobile data.
- Test on a small image first.
- Do not put secret API keys in frontend code.
- Before integrating AdBlueMedia, confirm its current terms allow the intended content-locking flow. Clearly tell users that completing an offer is required for the gated download. Never unlock based only on a browser-side callback.
