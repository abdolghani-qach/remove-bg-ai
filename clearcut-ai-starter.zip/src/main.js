import "./style.css";
import { removeBackground } from "@imgly/background-removal";

document.querySelector("#app").innerHTML = `
  <header class="topbar">
    <a class="brand" href="#"><span class="brand-mark">✦</span> ClearCut <span class="muted">AI</span></a>
    <span class="pill"><span class="dot"></span> Runs in your browser</span>
  </header>
  <main>
    <section class="hero">
      <div class="eyebrow">AI IMAGE TOOL</div>
      <h1>Remove backgrounds.<br><span>Keep the magic.</span></h1>
      <p class="subtitle">Create a transparent PNG in a few taps. Upload an image to get started.</p>
    </section>

    <section class="workspace">
      <div class="upload-panel" id="dropzone">
        <div class="upload-icon">↑</div>
        <h2>Drop your image here</h2>
        <p>or choose a file from your phone</p>
        <label class="choose-btn" for="fileInput">Choose image</label>
        <input id="fileInput" type="file" accept="image/png,image/jpeg,image/webp" hidden />
        <small>PNG, JPG or WebP · Max 12 MB</small>
      </div>

      <div class="preview-grid hidden" id="previewGrid">
        <div class="preview-card">
          <div class="preview-label">Original</div>
          <div class="image-stage"><img id="originalImg" alt="Original upload" /></div>
        </div>
        <div class="preview-card">
          <div class="preview-label">Background removed</div>
          <div class="image-stage checker"><img id="resultImg" alt="Background removed result" /></div>
        </div>
      </div>

      <div class="actions">
        <button id="processBtn" class="primary-btn" disabled>✦ Remove background</button>
        <button id="downloadBtn" class="secondary-btn hidden" disabled>Download PNG</button>
      </div>
      <div id="status" class="status" role="status">Choose an image to begin.</div>
      <div class="progress-track hidden" id="progressTrack"><div class="progress-bar" id="progressBar"></div></div>
      <p class="privacy-note">Your image is processed on your device in this prototype. Large images may take a little while on mobile.</p>
    </section>

    <section class="steps">
      <div><b>01</b><strong>Upload</strong><span>Choose a photo</span></div>
      <div><b>02</b><strong>Process</strong><span>AI removes the background</span></div>
      <div><b>03</b><strong>Download</strong><span>Save a transparent PNG</span></div>
    </section>
    <footer>ClearCut AI · Prototype · <span>Content Locker integration is not enabled yet.</span></footer>
  </main>
`;

const input = document.querySelector("#fileInput");
const dropzone = document.querySelector("#dropzone");
const processBtn = document.querySelector("#processBtn");
const downloadBtn = document.querySelector("#downloadBtn");
const status = document.querySelector("#status");
const previewGrid = document.querySelector("#previewGrid");
const originalImg = document.querySelector("#originalImg");
const resultImg = document.querySelector("#resultImg");
const progressTrack = document.querySelector("#progressTrack");
const progressBar = document.querySelector("#progressBar");

let selectedFile = null;
let resultUrl = null;

function setStatus(message, type = "") {
  status.textContent = message;
  status.className = `status ${type}`;
}
function loadFile(file) {
  if (!file) return;
  if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) {
    setStatus("Please choose a PNG, JPG, or WebP image.", "error");
    return;
  }
  if (file.size > 12 * 1024 * 1024) {
    setStatus("This image is over 12 MB. Choose a smaller file.", "error");
    return;
  }
  selectedFile = file;
  originalImg.src = URL.createObjectURL(file);
  previewGrid.classList.remove("hidden");
  resultImg.removeAttribute("src");
  downloadBtn.classList.add("hidden");
  processBtn.disabled = false;
  setStatus(`Ready: ${file.name}`);
}
input.addEventListener("change", e => loadFile(e.target.files?.[0]));
dropzone.addEventListener("dragover", e => { e.preventDefault(); dropzone.classList.add("dragging"); });
dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragging"));
dropzone.addEventListener("drop", e => {
  e.preventDefault();
  dropzone.classList.remove("dragging");
  loadFile(e.dataTransfer.files?.[0]);
});

processBtn.addEventListener("click", async () => {
  if (!selectedFile) return;
  processBtn.disabled = true;
  downloadBtn.disabled = true;
  progressTrack.classList.remove("hidden");
  progressBar.style.width = "8%";
  setStatus("Loading AI model… Keep this tab open.");
  try {
    // The model downloads on first use; processing time depends on your device and connection.
    let progress = 8;
    const timer = setInterval(() => {
      progress = Math.min(progress + Math.random() * 7, 90);
      progressBar.style.width = `${progress}%`;
    }, 700);
    const blob = await removeBackground(selectedFile, {
      progress: (key, current, total) => {
        if (total > 0) {
          const p = Math.round((current / total) * 100);
          setStatus(`Processing image… ${p}%`);
        }
      }
    });
    clearInterval(timer);
    progressBar.style.width = "100%";
    if (resultUrl) URL.revokeObjectURL(resultUrl);
    resultUrl = URL.createObjectURL(blob);
    resultImg.src = resultUrl;
    downloadBtn.classList.remove("hidden");
    downloadBtn.disabled = false;
    setStatus("Done! Your transparent PNG is ready.", "success");
  } catch (err) {
    console.error(err);
    setStatus("Could not process this image. Try a smaller image or a stronger connection.", "error");
  } finally {
    processBtn.disabled = false;
    setTimeout(() => progressTrack.classList.add("hidden"), 900);
  }
});

downloadBtn.addEventListener("click", () => {
  if (!resultUrl) return;
  const a = document.createElement("a");
  a.href = resultUrl;
  a.download = "clearcut-background-removed.png";
  document.body.appendChild(a);
  a.click();
  a.remove();
});
